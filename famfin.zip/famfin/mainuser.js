// Get the button element
const myButton = document.getElementById("myButton");

// Add an event listener for the "click" event
myButton.addEventListener("click", function() {
  // Display a message using the alert function
  alert("New member added successfully!");
});
